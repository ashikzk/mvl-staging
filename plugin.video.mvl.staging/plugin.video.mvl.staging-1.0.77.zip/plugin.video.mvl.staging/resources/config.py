__author__ = 'ashik'

plugin_id = 'plugin.video.mvl.staging'
skin_id = 'skin.mvl.staging'
